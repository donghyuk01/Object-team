import mysql.connector

# DB 연결
conn = mysql.connector.connect(
    host="155.230.235.248",
    port="32065",
    user="mir9876",
    password="rlaehdgur",
    database="mir9876"
)
cursor = conn.cursor()

# PNG 파일 읽기
with open("sample.png", "rb") as f:
    blob_data = f.read()

# INSERT 실행
sql = "INSERT INTO new_table (Img) VALUES (%s)"
cursor.execute(sql, (blob_data,))
conn.commit()

print("PNG 저장 완료!")

cursor.close()
conn.close()
