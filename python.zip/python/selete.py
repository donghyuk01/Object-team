import mysql.connector

conn = mysql.connector.connect(
    host="155.230.235.248",
    port="32065",
    user="mir9876",
    password="rlaehdgur",
    database="mir9876"
)
cursor = conn.cursor()

cursor.execute("SELECT Img FROM new_table")
row = cursor.fetchone()

if row:
    with open("restored.png", "wb") as f:
        f.write(row[0])
    print("이미지가 restored.png 로 복원되었습니다.")

cursor.close()
conn.close()