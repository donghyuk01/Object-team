import mysql.connector
# DB 연결
conn = mysql.connector.connect(
    host="155.230.235.248",
    port="32065",
    user="mir9876",
    password="rlaehdgur",
    database="mir9876"
)
cursor = conn.cursor()
cursor.execute("delete from new_table where i_id <> 0")
conn.commit()
cursor.close()
conn.close()
