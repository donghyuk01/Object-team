﻿
// sqlblobView.cpp: CsqlblobView 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "sqlblob.h"
#endif

#include "sqlblobDoc.h"
#include "sqlblobView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CsqlblobView

IMPLEMENT_DYNCREATE(CsqlblobView, CFormView)

BEGIN_MESSAGE_MAP(CsqlblobView, CFormView)
	// 표준 인쇄 명령입니다.
	ON_COMMAND(ID_FILE_PRINT, &CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CFormView::OnFilePrintPreview)
	ON_BN_CLICKED(IDC_BUTTON1, &CsqlblobView::OnBnClickedButton1)
END_MESSAGE_MAP()

// CsqlblobView 생성/소멸

CsqlblobView::CsqlblobView() noexcept
	: CFormView(IDD_SQLBLOB_FORM)
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

CsqlblobView::~CsqlblobView()
{
}

void CsqlblobView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BOOL CsqlblobView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CFormView::PreCreateWindow(cs);
}

void CsqlblobView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	db.OpenEx(_T("DSN=blob;UID=mir9876;PWD=rlaehdgur;"), CDatabase::noOdbcDialog);
}


// CsqlblobView 인쇄

BOOL CsqlblobView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);
}

void CsqlblobView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄하기 전에 추가 초기화 작업을 추가합니다.
}

void CsqlblobView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄 후 정리 작업을 추가합니다.
}

void CsqlblobView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: 여기에 사용자 지정 인쇄 코드를 추가합니다.
}


// CsqlblobView 진단

#ifdef _DEBUG
void CsqlblobView::AssertValid() const
{
	CFormView::AssertValid();
}

void CsqlblobView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CsqlblobDoc* CsqlblobView::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CsqlblobDoc)));
	return (CsqlblobDoc*)m_pDocument;
}
#endif //_DEBUG


// CsqlblobView 메시지 처리기

void CsqlblobView::OnBnClickedButton1()
{
    try {
        // ODBC 연결 핸들 얻기
        HDBC hDbc = db.m_hdbc;
        SQLHSTMT hStmt;

        // Statement 핸들 할당
        SQLRETURN ret = SQLAllocHandle(SQL_HANDLE_STMT, hDbc, &hStmt);
        if (ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
            AfxMessageBox(_T("SQLAllocHandle 실패"));
            return;
        }

        // 유니코드 SQL 문
        SQLWCHAR sql[] = L"INSERT INTO mir9876.new_table (Img) VALUES (?)";

        // SQL 문 준비
        ret = SQLPrepareW(hStmt, sql, SQL_NTS);
        if (ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
            AfxMessageBox(_T("SQLPrepare 실패"));
            SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
            return;
        }

        // 이미지 파일 읽기
        std::ifstream file("C:\\Users\\cosmo\\source\\repos\\sqlblob\\x64\\Debug\\sample.png", std::ios::binary);
        if (!file.is_open()) {
            AfxMessageBox(_T("sample.png 파일을 열 수 없습니다"));
            SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
            return;
        }
        std::vector<char> buffer((std::istreambuf_iterator<char>(file)), {});

        // 길이 값 지정 (매우 중요)
        SQLLEN cbData = (SQLLEN)buffer.size();

        ret = SQLBindParameter(
            hStmt,
            1,
            SQL_PARAM_INPUT,
            SQL_C_BINARY,         // C 타입
            SQL_LONGVARBINARY,    // SQL 타입
            buffer.size(),
            0,
            (SQLPOINTER)buffer.data(),
            buffer.size(),
            &cbData               // ← 반드시 필요!
        );

        if (ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
            AfxMessageBox(_T("SQLBindParameter 실패"));
            SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
            return;
        }
        if (ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
            AfxMessageBox(_T("SQLBindParameter 실패"));
            SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
            return;
        }

        // SQL 실행
        ret = SQLExecute(hStmt);
        if (ret == SQL_SUCCESS || ret == SQL_SUCCESS_WITH_INFO) {
            AfxMessageBox(_T("데이터 저장 완료"));
        }
        else {
            AfxMessageBox(_T("SQLExecute 실패"));
        }

        // 핸들 정리
        SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    }
    catch (...) {
        AfxMessageBox(_T("예외 발생"));
    }
}