﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// My.rc에서 사용되고 있습니다.
//
#define ID_UserCancel                   2
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_MY_FORM                     101
#define IDR_MAINFRAME                   128
#define IDR_MyTYPE                      130
#define IDD_User                        315
#define IDD_Book_reg                    319
#define IDD_Loan                        321
#define IDC_BUTTON1                     1000
#define IDC_BUTTON2                     1001
#define IDC_BUTTON3                     1002
#define IDC_BUTTON5                     1003
#define IDC_EDIT1                       1004
#define IDC_EDIT2                       1005
#define IDC_BUTTON4                     1006
#define IDC_EDIT3                       1006
#define IDC_MainSearch                  1006
#define IDC_EDIT4                       1007
#define IDC_COMBO3                      1008
#define IDC_EDIT6                       1008
#define IDC_LIST1                       1009
#define IDC_EDIT7                       1009
#define IDCANCEL                        1011
#define IDC_EDIT5                       1012
#define IDC_COMBO1                      1016
#define IDC_LIST2                       1017
#define IDC_Userform                    1018
#define IDC_Bookform                    1019
#define IDC_Loanform                    1020
#define ID_BookReg                      1021
#define IDC_BookUpdate                  1022
#define IDC_BookDel                     1023
#define IDC_BookImg                     1024
#define IDC_BookClose                   1025
#define ID_GotoMain                     1026
#define IDC_COMBO2                      1027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        323
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
