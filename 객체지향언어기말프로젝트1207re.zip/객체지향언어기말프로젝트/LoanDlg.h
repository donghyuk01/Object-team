﻿#pragma once
#include "afxdialogex.h"


// LoanDlg 대화 상자
class UserDlg;
class LoanDlg : public CDialogEx
{
	DECLARE_DYNAMIC(LoanDlg)

public:
	LoanDlg(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~LoanDlg();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_Loan };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.
	virtual void OnCancel();
	DECLARE_MESSAGE_MAP()
public:
	UserDlg* loanView;
	/*afx_msg void OnBnClickedLoanclose();*/
};
