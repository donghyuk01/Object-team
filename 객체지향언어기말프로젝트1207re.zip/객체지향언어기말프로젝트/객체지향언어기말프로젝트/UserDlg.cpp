﻿// UserDlg.cpp: 구현 파일
//

#include "pch.h"
#include "객체지향언어기말프로젝트.h"
#include "afxdialogex.h"
#include "UserDlg.h"

#include"객체지향언어기말프로젝트Doc.h"
#include"객체지향언어기말프로젝트View.h"
#include"LoanDlg.h"
// UserDlg 대화 상자

IMPLEMENT_DYNAMIC(UserDlg, CDialogEx)

UserDlg::UserDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_User, pParent)
{
	userView = (C객체지향언어기말프로젝트View*)pParent;
    ld = NULL;
}

UserDlg::~UserDlg()
{
}

void UserDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT5, userName);
	DDX_Control(pDX, IDC_EDIT8, birth);
	DDX_Control(pDX, IDC_EDIT9, maxLoan);
	DDX_Control(pDX, IDC_EDIT10, solveDate);
	DDX_Control(pDX, IDC_COMBO1, statusBox);
	DDX_Control(pDX, IDC_LIST1, user_lc);
}


BEGIN_MESSAGE_MAP(UserDlg, CDialogEx)
	/*ON_BN_CLICKED(ID_UserCancel, &UserDlg::OnBnClickedUsercancel)*/
	ON_BN_CLICKED(IDC_BUTTON5, &UserDlg::OnBnClickedButton5)
    ON_BN_CLICKED(IDC_LoanButton, &UserDlg::OnBnClickedLoanbutton)
END_MESSAGE_MAP()


// UserDlg 메시지 처리기
BOOL UserDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    // TODO:  여기에 추가 초기화 작업을 추가합니다.
    statusBox.ResetContent();
    statusBox.AddString(_T("정상"));
    statusBox.AddString(_T("연체 정지"));
    statusBox.AddString(_T("자격 정지"));
    statusBox.AddString(_T("탈퇴"));
    statusBox.SetCurSel(0);

    user_lc.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);

    
    user_lc.InsertColumn(0, _T("도서 ID"), LVCFMT_LEFT, 120); 
    user_lc.InsertColumn(1, _T("대출일"), LVCFMT_LEFT, 200);
    user_lc.InsertColumn(2, _T("반납 예정일"), LVCFMT_LEFT, 200);
    user_lc.InsertColumn(3, _T("상태"), LVCFMT_LEFT, 80);
    user_lc.InsertColumn(4, _T("연체일수"), LVCFMT_RIGHT, 80);

    return TRUE;  // return TRUE unless you set the focus to a control
    // 예외: OCX 속성 페이지는 FALSE를 반환해야 합니다.
}
void UserDlg::OnCancel()
{
    // X 버튼이나 ESC로 닫힐 때만 호출됩니다.
    userView->ud = NULL;
    // 부모 클래스의 OnCancel() 호출 (자동으로 DestroyWindow()와 delete this를 안전하게 처리)
    CDialogEx::OnCancel();
}
//void UserDlg::OnBnClickedUsercancel()
//{
//	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
//	/*userView->ud = NULL;
//	DestroyWindow();
//	delete this;*/
//    /*OnCancel();*/
//
//}
void UserDlg::LoadUserLoanList(const CString& strUserID)
{
    // 리스트 컨트롤 초기화
    user_lc.DeleteAllItems();

    CDatabase* pDB = &userView->db;

    if (pDB == NULL || !pDB->IsOpen())
    {
        AfxMessageBox(_T("데이터베이스 연결 상태를 확인해주세요."));
        return;
    }

    // SQL 쿼리 작성: ItemID (바코드), 대출 정보 조회
    // CListCtrl 칼럼: (0: 도서 ID/바코드, 1: 대출일, 2: 반납 예정일, 3: 상태, 4: 연체일수)
    CString strSQL;
    strSQL.Format(_T("SELECT ")
        _T("BI.itemID, L.LoanDate, L.DueDate, L.LoanStatus, L.OverdueDays ")
        _T("FROM mir9876.Loan L ")
        _T("JOIN mir9876.Book_item BI ON L.ItemID = BI.itemID ")
        _T("WHERE L.UserID = %s AND L.LoanStatus IN ('대출 중', '연체') ") // 반납되지 않은 책만 조회
        _T("ORDER BY L.LoanDate DESC"),
        strUserID);

    CRecordset rs(pDB);
    TRY
    {
        if (!rs.Open(CRecordset::forwardOnly, strSQL))
        {
            AfxMessageBox(_T("대출 목록 조회 쿼리 실행에 실패했습니다."));
            return;
        }

        int nRow = 0;
        while (!rs.IsEOF())
        {
            // 각 칼럼 값 가져오기
            CString strItemID, strLoanDate, strDueDate, strLoanStatus, strOverdueDays;

            rs.GetFieldValue(_T("itemID"), strItemID);
            rs.GetFieldValue(_T("LoanDate"), strLoanDate);
            rs.GetFieldValue(_T("DueDate"), strDueDate);
            rs.GetFieldValue(_T("LoanStatus"), strLoanStatus);
            rs.GetFieldValue(_T("OverdueDays"), strOverdueDays);

            // DateTime 형식 문자열에서 시간 부분 제거 (YYYY-MM-DD hh:mm:ss -> YYYY-MM-DD)
            int nSpacePos = strLoanDate.Find(' ');
            if (nSpacePos != -1)
            {
                strLoanDate = strLoanDate.Left(nSpacePos);
            }

            // 리스트 컨트롤에 항목 삽입 (5개 칼럼 순서에 맞춤)
            user_lc.InsertItem(nRow, strItemID);          // 0. 도서 ID
            user_lc.SetItemText(nRow, 1, strLoanDate);    // 2. 대출일
            user_lc.SetItemText(nRow, 2, strDueDate);     // 3. 반납 예정일
            user_lc.SetItemText(nRow, 3, strLoanStatus);  // 4. 상태
            user_lc.SetItemText(nRow, 4, strOverdueDays); // 5. 연체일


            rs.MoveNext();
            nRow++;
        }
    }
        CATCH(CDBException, e)
    {
        AfxMessageBox(_T("대출 목록 조회 중 데이터베이스 오류 발생: ") + e->m_strError);
    }
    END_CATCH

        rs.Close();
}

void UserDlg::OnBnClickedButton5()
{
    
    CString strName, strBirth;
    userName.GetWindowText(strName);
    birth.GetWindowText(strBirth);

   
    if (strName.IsEmpty() || strBirth.IsEmpty())
    {
        AfxMessageBox(_T("이름과 생년월일을 모두 입력해주세요."));
        return;
    }

    
    CDatabase* pDB = &userView->db;

    
    if (pDB == NULL || !pDB->IsOpen())
    {
        AfxMessageBox(_T("데이터베이스 연결 상태를 확인해주세요."));
        return;
    }

    
    CString strSQL;
    strSQL.Format(_T("SELECT userID, maxLoan, solveDate, status FROM mir9876.User WHERE name='%s' AND birth='%s'"),
        strName, strBirth);

    CRecordset rs(pDB);
    TRY
    {

        if (!rs.Open(CRecordset::forwardOnly, strSQL))
        {
            AfxMessageBox(_T("회원 조회 쿼리 실행에 실패했습니다."));
            return;
        }

    
    if (rs.IsEOF())
    {
        
        AfxMessageBox(_T("입력하신 이름과 생년월일로 등록된 회원이 없습니다."));

        
        maxLoan.SetWindowText(_T(""));
        solveDate.SetWindowText(_T(""));
        statusBox.SetCurSel(-1); 
    }
    else
    {
        
        CString strUserID, strMaxLoan, strSolveDate, strStatus;

        
        rs.GetFieldValue(_T("userID"), strUserID);
        rs.GetFieldValue(_T("maxLoan"), strMaxLoan);
        rs.GetFieldValue(_T("solveDate"), strSolveDate);
        rs.GetFieldValue(_T("status"), strStatus);

        LoadUserLoanList(strUserID);
        

        int nMaxLoanLimit = _ttoi(strMaxLoan);         // 최대 한도를 숫자로 변환
        int nCurrentLoanCount = user_lc.GetItemCount(); // 현재 대출 중인 권수 획득
        int nRemainingLoanCount = nMaxLoanLimit - nCurrentLoanCount; // 남은 권수 계산

        CString strRemainingCount;
        strRemainingCount.Format(_T("%d"), nRemainingLoanCount);

        // 3. 계산된 남은 권수를 UI에 표시
        maxLoan.SetWindowText(strRemainingCount);

        if (strSolveDate.IsEmpty() || strSolveDate == _T("0000-00-00"))
        {
            solveDate.SetWindowText(_T("없음"));
        }
        else
        {
            solveDate.SetWindowText(strSolveDate);
        }

        
        int index = statusBox.FindStringExact(-1, strStatus);
        if (index != CB_ERR)
        {
            statusBox.SetCurSel(index);
        }
        else
        {
            statusBox.SetCurSel(-1);
        }

  
        /*LoadUserLoanList(strUserID);*/ 
    }
    }
        CATCH(CDBException, e)
    {
        
        AfxMessageBox(e->m_strError);
        
        maxLoan.SetWindowText(_T(""));
        solveDate.SetWindowText(_T(""));
        statusBox.SetCurSel(-1);
    }
    END_CATCH

        rs.Close(); 


}



void UserDlg::OnBnClickedLoanbutton()
{
    // TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
    if (ld == NULL) {
        ld  = new LoanDlg(this);
        ld->Create(IDD_Loan);
        ld->ShowWindow(SW_SHOW);
    }
    else {
        ld->SetFocus();
    }
    
}
