﻿#pragma once
#include "afxdialogex.h"

#include <afxdb.h>
// LoanDlg 대화 상자
class UserDlg;
class C객체지향언어기말프로젝트View;
class LoanDlg : public CDialogEx
{
	DECLARE_DYNAMIC(LoanDlg)

public:
	LoanDlg(CDatabase* pDB,CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~LoanDlg();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_Loan };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.
	virtual void OnCancel();
	DECLARE_MESSAGE_MAP()
public:
	UserDlg* loanView;
	/*afx_msg void OnBnClickedLoanclose();*/
	CEdit lEc;
	afx_msg void OnBnClickedAddbook();
	afx_msg void OnBnClickedCombo1();
	afx_msg void OnBnClickedLoan();
	afx_msg void OnBnClickedReturn();
	CListCtrl lc;
	CDatabase* m_pDB;
	CString m_strUserName;
	CString m_strUserID;

	virtual BOOL OnInitDialog();
	CEdit userName;
};
