﻿// LoanDlg.cpp: 구현 파일
//

#include "pch.h"

#include "afxdialogex.h"
#include "LoanDlg.h"
	
#include "UserDlg.h"
#include "객체지향언어기말프로젝트.h"


#include <afxdb.h>

// LoanDlg 대화 상자

IMPLEMENT_DYNAMIC(LoanDlg, CDialogEx)

LoanDlg::LoanDlg(CDatabase* pDB, CWnd* pParent)
	: CDialogEx(IDD_Loan, pParent), m_pDB(pDB)
{
	loanView = (UserDlg*)pParent;
}


LoanDlg::~LoanDlg()
{
}

void LoanDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT2, lEc);
	DDX_Control(pDX, IDC_LIST1, lc);
	DDX_Control(pDX, IDC_EDIT1, userName);
}


BEGIN_MESSAGE_MAP(LoanDlg, CDialogEx)
	/*ON_BN_CLICKED(ID_LoanClose, &LoanDlg::OnBnClickedLoanclose)*/
	ON_BN_CLICKED(IDC_AddBook, &LoanDlg::OnBnClickedAddbook)
	ON_BN_CLICKED(IDC_COMBO1, &LoanDlg::OnBnClickedCombo1)
	ON_BN_CLICKED(IDC_Loan, &LoanDlg::OnBnClickedLoan)
	ON_BN_CLICKED(IDC_Return, &LoanDlg::OnBnClickedReturn)
END_MESSAGE_MAP()


// LoanDlg 메시지 처리기
void LoanDlg::OnCancel()
{
	
	if (loanView) {
		loanView->ld = NULL;
	}
	
	CDialogEx::OnCancel();
}


void LoanDlg::OnBnClickedAddbook()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	CString itemId;
	lEc.GetWindowText(itemId);
	itemId.Trim();
	if (itemId.IsEmpty())
	{
		AfxMessageBox(_T("도서 ID를 입력해주세요."));
		return;
	}
	if (m_pDB == nullptr || !m_pDB->IsOpen())
	{
		AfxMessageBox(_T("DB 연결이 되어 있지 않습니다."));
		return;
	}
	try
	{
		CString strSQL;
		strSQL.Format(
			_T("SELECT bi.itemID, b.title, b.author ")
			_T("FROM mir9876.Book_item bi ")
			_T("JOIN mir9876.Book b ON bi.bookID = b.bookID ")
			_T("WHERE bi.itemID = '%s'"),
			itemId
		);

		CRecordset rs(m_pDB);
		rs.Open(CRecordset::forwardOnly, strSQL, CRecordset::readOnly);

		if (rs.IsEOF())
		{
			AfxMessageBox(_T("해당 도서가 존재하지 않습니다."));
			rs.Close();
			return;
		}

		CString dbItemID, title, author;

		rs.GetFieldValue((short)0, dbItemID); 
		rs.GetFieldValue((short)1, title);    
		rs.GetFieldValue((short)2, author);   

		rs.Close();

		
		int nRow = lc.InsertItem(lc.GetItemCount(), dbItemID);
		lc.SetItemText(nRow, 1, title);
		lc.SetItemText(nRow, 2, author);
		lEc.SetWindowText(_T(""));
	}
	catch (CDBException* e)
	{
		AfxMessageBox(e->m_strError);
		e->Delete();
	}



	
}

void LoanDlg::OnBnClickedCombo1() //삭제
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	int nSelectedCount = lc.GetSelectedCount();
	if (nSelectedCount == 0)
	{
		AfxMessageBox(_T("삭제할 도서를 선택하세요."));
		return;
	}

	
	for (int i = lc.GetItemCount() - 1; i >= 0; i--)
	{
		if (lc.GetItemState(i, LVIS_SELECTED) & LVIS_SELECTED)
		{
			lc.DeleteItem(i);
		}
	}

	lEc.SetWindowText(_T(""));
}

void LoanDlg::OnBnClickedLoan()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	if (m_pDB == nullptr || !m_pDB->IsOpen())
	{
		AfxMessageBox(_T("DB 연결 상태를 확인해주세요."));
		return;
	}
	int nRemainLoan = 0;
	if (loanView)
	{
		CString strRemain;
		loanView->maxLoan.GetWindowText(strRemain);
		nRemainLoan = _ttoi(strRemain);
	}

	int nRequestCount = lc.GetItemCount();

	if (nRequestCount > nRemainLoan)
	{
		CString msg;
		msg.Format(_T("대출 가능 권수를 초과했습니다.\n\n남은 권수: %d\n선택한 도서: %d권"),
			nRemainLoan, nRequestCount);
		AfxMessageBox(msg);
		return;
	}

	int nItemCount = lc.GetItemCount();
	if (nItemCount == 0)
	{
		AfxMessageBox(_T("대출할 도서가 없습니다."));
		return;
	}

	
	CString strUserID = m_strUserID;
	strUserID.Trim(); 

	if (strUserID.IsEmpty())
	{
		AfxMessageBox(_T("사용자 ID가 지정되지 않았습니다."));
		return;
	}

	int nUserID = _ttoi(strUserID);

	
	if (nUserID == 0)
	{
		
		AfxMessageBox(_T("유효하지 않은 사용자 ID입니다."));
		return;
	}
	


	TRY
	{
		for (int i = 0; i < nItemCount; i++)
		{
			CString itemID = lc.GetItemText(i, 0);

			CString strCheckSQL;
			strCheckSQL.Format(
				_T("SELECT status FROM mir9876.Book_item WHERE itemID='%s'"),
				itemID
			);

			CRecordset rs(m_pDB);
			rs.Open(CRecordset::forwardOnly, strCheckSQL, CRecordset::readOnly);

			if (rs.IsEOF())
			{
				rs.Close();
				AfxMessageBox(_T("도서 정보를 확인할 수 없습니다."));
				return;
			}

			CString status;
			rs.GetFieldValue((short)0, status);
			rs.Close();

			if (status != _T("대출 가능"))
			{
				CString msg;
				msg.Format(
					_T("도서 [%s] 는 대출할 수 없는 상태입니다.\n\n현재 상태: %s"),
					itemID, status
				);
				AfxMessageBox(msg);
				return; 
			}


			CString strLoanSQL;
			strLoanSQL.Format(
				_T("INSERT INTO mir9876.Loan ")
				_T("(ItemID, UserID, LoanDate, DueDate, LoanStatus, OverdueDays) ")
				_T("VALUES ('%s', %d, NOW(), DATE_ADD(CURDATE(), INTERVAL 14 DAY), '대출 중', 0)"),
				itemID, nUserID 
			);

			

			m_pDB->ExecuteSQL(strLoanSQL);


			CString strUpdateSQL;
			strUpdateSQL.Format(
				_T("UPDATE mir9876.Book_item SET status='대출 중' WHERE itemID='%s'"),
				itemID
			);

			m_pDB->ExecuteSQL(strUpdateSQL);
		}

		AfxMessageBox(_T("대출이 완료되었습니다."));
		lEc.SetWindowText(_T(""));

		lc.DeleteAllItems();
		if (loanView)
		{
			loanView->RefreshUserInfo();
		}
	}
		CATCH(CDBException, e)
	{
		AfxMessageBox(_T("대출 처리 중 오류 발생:\n") + e->m_strError);
		e->Delete();
	}
	END_CATCH
}

void LoanDlg::OnBnClickedReturn()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	if (m_pDB == nullptr || !m_pDB->IsOpen())
	{
		AfxMessageBox(_T("DB 연결 상태를 확인해주세요."));
		return;
	}

	int nItemCount = lc.GetItemCount();
	if (nItemCount == 0)
	{
		AfxMessageBox(_T("반납할 도서가 없습니다."));
		return;
	}

	int nUserID = _ttoi(m_strUserID);
	if (nUserID == 0)
	{
		AfxMessageBox(_T("유효하지 않은 사용자 ID입니다."));
		return;
	}

	for (int i = 0; i < nItemCount; i++)
	{
		CString itemID = lc.GetItemText(i, 0);

		try
		{
			CString strReturnSQL;
			strReturnSQL.Format(
				_T("UPDATE mir9876.Loan SET LoanStatus='반납 완료' ")
				_T("WHERE ItemID='%s' AND UserID=%d AND LoanStatus='대출 중'"),
				itemID, nUserID
			);
			m_pDB->ExecuteSQL(strReturnSQL);

			CString strUpdateBookSQL;
			strUpdateBookSQL.Format(
				_T("UPDATE mir9876.Book_item SET status='보관 중' WHERE itemID='%s'"),
				itemID
			);
			m_pDB->ExecuteSQL(strUpdateBookSQL);
		}
		catch (CDBException* e)
		{
			
			e->Delete();
		}
	}
	lc.DeleteAllItems();
	AfxMessageBox(_T("반납이 완료되었습니다."));

	if (loanView)
	{
		loanView->RefreshUserInfo();
	}
}

BOOL LoanDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  여기에 추가 초기화 작업을 추가합니다.
	userName.SetWindowText(m_strUserName);

	DWORD style = lc.GetExtendedStyle();
	lc.SetExtendedStyle(style | LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	lc.ModifyStyle(LVS_SINGLESEL, 0);
	lc.InsertColumn(0, _T("바코드"), LVCFMT_LEFT, 100);
	lc.InsertColumn(1, _T("책 제목"), LVCFMT_LEFT, 250);
	lc.InsertColumn(2, _T("저자"), LVCFMT_LEFT, 200);


	return TRUE; 
	// 예외: OCX 속성 페이지는 FALSE를 반환해야 합니다.
}
