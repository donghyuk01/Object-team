﻿#pragma once
#include "afxdialogex.h"

#include <afxinet.h>
// bookDIg 대화 상자
class C객체지향언어기말프로젝트View;
class bookDIg : public CDialogEx
{
	DECLARE_DYNAMIC(bookDIg)

public:
	bookDIg(CWnd* pParent = nullptr);   // 표준 생성자입니다.
	virtual ~bookDIg();

	// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_Book_reg };
#endif
private:
	 
	
	void LoadServerInfo(CString& strServer, INTERNET_PORT& nPort, DWORD& dwSecure, DWORD& dwSecureFlag);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.
	virtual void OnCancel();
	
	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnBnClickedBookreg();
	afx_msg void OnBnClickedBookupdate();
	afx_msg void OnBnClickedBookdel();
	unsigned int m_bookId;
	CEdit bec1;
	CEdit bec2;
	CEdit bec3;
	CComboBox bcb1;
	afx_msg void OnBnClickedBookimg();
	/*afx_msg void OnBnClickedBookclose();*/
	virtual BOOL OnInitDialog();
	C객체지향언어기말프로젝트View* bookView;
	CStringA Base64Encode(const BYTE* pData, DWORD length);
	CString m_strImagePath; 
	void SetBookIdToLoad(DWORD bookId) { m_bookId = bookId; }
	void LoadBookDetail(DWORD bookId);
};
