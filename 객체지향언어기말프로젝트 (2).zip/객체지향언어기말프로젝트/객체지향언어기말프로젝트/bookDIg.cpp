﻿// bookDIg.cpp: 구현 파일
//

#include "pch.h"
#include "객체지향언어기말프로젝트.h"
#include "afxdialogex.h"
#include "bookDIg.h"

#include"객체지향언어기말프로젝트Doc.h";
#include "객체지향언어기말프로젝트View.h";


// bookDIg 대화 상자

IMPLEMENT_DYNAMIC(bookDIg, CDialogEx)

bookDIg::bookDIg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_Book_reg, pParent)
{
	bookView = (C객체지향언어기말프로젝트View*)pParent;
}

bookDIg::~bookDIg()
{
}

void bookDIg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, bec1);
	DDX_Control(pDX, IDC_EDIT2, bec2);
	DDX_Control(pDX, IDC_EDIT3, bec3);
	DDX_Control(pDX, IDC_COMBO1, bcb1);
}


BEGIN_MESSAGE_MAP(bookDIg, CDialogEx)
	ON_BN_CLICKED(ID_BookReg, &bookDIg::OnBnClickedBookreg)
	ON_BN_CLICKED(IDC_BookUpdate, &bookDIg::OnBnClickedBookupdate)
	ON_BN_CLICKED(IDC_BookDel, &bookDIg::OnBnClickedBookdel)
	ON_BN_CLICKED(IDC_BookImg, &bookDIg::OnBnClickedBookimg)
	ON_BN_CLICKED(IDC_BookClose, &bookDIg::OnBnClickedBookclose)
END_MESSAGE_MAP()


// bookDIg 메시지 처리기

void bookDIg::OnBnClickedBookreg()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}

void bookDIg::OnBnClickedBookupdate()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}

void bookDIg::OnBnClickedBookdel()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}

void bookDIg::OnBnClickedBookimg()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
}



void bookDIg::OnBnClickedBookclose()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	bookView->bd = NULL;
	DestroyWindow();
	delete this;
}
