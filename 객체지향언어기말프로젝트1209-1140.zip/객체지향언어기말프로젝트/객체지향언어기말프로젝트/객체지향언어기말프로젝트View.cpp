﻿// 객체지향언어기말프로젝트View.cpp: C객체지향언어기말프로젝트View 클래스의 구현
//

#include "pch.h"
#include "framework.h"
#ifndef SHARED_HANDLERS
#include "객체지향언어기말프로젝트.h"
#endif

#include "객체지향언어기말프로젝트Doc.h"
#include "객체지향언어기말프로젝트View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#include "bookDIg.h"
#include "UserDlg.h"
#include "LoanDlg.h"
// C객체지향언어기말프로젝트View

IMPLEMENT_DYNCREATE(C객체지향언어기말프로젝트View, CFormView)

BEGIN_MESSAGE_MAP(C객체지향언어기말프로젝트View, CFormView)
	ON_COMMAND(ID_FILE_PRINT, &CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CFormView::OnFilePrintPreview)
	ON_BN_CLICKED(IDC_Userform, &C객체지향언어기말프로젝트View::OnBnClickedUserform)
	ON_BN_CLICKED(IDC_Bookform, &C객체지향언어기말프로젝트View::OnBnClickedBookform)
	ON_BN_CLICKED(IDC_Loanform, &C객체지향언어기말프로젝트View::OnBnClickedLoanform)
	ON_BN_CLICKED(IDC_MainSearch, &C객체지향언어기말프로젝트View::OnBnClickedMainsearch)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_LIST1, &C객체지향언어기말프로젝트View::OnNMCustomdrawList1)
	ON_WM_MEASUREITEM()
	ON_CBN_SELCHANGE(IDC_COMBO3, &C객체지향언어기말프로젝트View::OnCbnSelchangeCombo3)
	ON_CBN_SELCHANGE(IDC_COMBO2, &C객체지향언어기말프로젝트View::OnCbnSelchangeCombo2)
	ON_NOTIFY(NM_CLICK, IDC_LIST1, &C객체지향언어기말프로젝트View::OnNMClickList1)
END_MESSAGE_MAP()

// C객체지향언어기말프로젝트View 생성/소멸

C객체지향언어기말프로젝트View::C객체지향언어기말프로젝트View() noexcept
	: CFormView(IDD_MY_FORM)
{
	bd = NULL;
	ud = NULL;

	m_pBookBitmap = NULL;
}

C객체지향언어기말프로젝트View::~C객체지향언어기말프로젝트View()
{
	if (m_pBookBitmap) {
		delete m_pBookBitmap;
	}
	mImageList.DeleteImageList();
	m_imageCache.clear();
	GdiplusShutdown(m_gdiplusToken);
}

void C객체지향언어기말프로젝트View::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, MainEc);
	DDX_Control(pDX, IDC_COMBO1, mCbs);
	DDX_Control(pDX, IDC_COMBO3, mCbc);
	DDX_Control(pDX, IDC_LIST1, mLc);
	DDX_Control(pDX, IDC_COMBO2, mCb3);
}

BOOL C객체지향언어기말프로젝트View::PreCreateWindow(CREATESTRUCT& cs)
{
	return CFormView::PreCreateWindow(cs);
}

void C객체지향언어기말프로젝트View::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	SetWindowText(_T("도서/대출 관리 프로그램"));
	mCbs.ResetContent();
	mCbc.ResetContent();

	mCbs.AddString(_T("제목"));
	mCbs.AddString(_T("저자"));
	mCbs.SetCurSel(0);

	mCbc.AddString(_T("최신순"));
	mCbc.AddString(_T("제목순"));
	mCbc.SetCurSel(0);

	mCb3.AddString(_T("전체"));
	mCb3.AddString(_T("철학"));
	mCb3.AddString(_T("종교"));
	mCb3.AddString(_T("사회과학"));
	mCb3.AddString(_T("자연과학"));
	mCb3.AddString(_T("기술과학"));
	mCb3.AddString(_T("예술"));
	mCb3.AddString(_T("언어"));
	mCb3.AddString(_T("문학"));
	mCb3.AddString(_T("역사"));
	mCb3.AddString(_T("기타"));
	mCb3.SetCurSel(0);

	GdiplusStartupInput gdiplusStartupInput;
	GdiplusStartup(&m_gdiplusToken, &gdiplusStartupInput, NULL);

	mLc.ModifyStyle(0, LVS_REPORT | LVS_OWNERDRAWFIXED);
	mLc.SetExtendedStyle(0);

	mLc.InsertColumn(0, _T("도서 정보"), LVCFMT_LEFT, 500);

	
	const int FINAL_SIZE = 150;

	
	mImageList.Create(FINAL_SIZE, FINAL_SIZE, ILC_COLOR32 | ILC_MASK, 1, 1);
	mLc.SetImageList(&mImageList, LVSIL_SMALL);

	
	HBITMAP hBmpOriginal = LoadPngToHBITMAP(_T("1.png"));

	int imgIndex = -1;
	if (hBmpOriginal)
	{
		
		HBITMAP hBmpResized = ResizeHBITMAP(hBmpOriginal, FINAL_SIZE, FINAL_SIZE);

		CBitmap bmp;
		bmp.Attach(hBmpResized);
		imgIndex = mImageList.Add(&bmp, RGB(255, 255, 255));
		bmp.Detach();

		
		DeleteObject(hBmpOriginal);
	}

	db.OpenEx(_T("DSN=blob;UID=mir9876;PWD=rlaehdgur;"), CDatabase::noOdbcDialog);
	CString strDefaultSort;
	mCbc.GetLBText(0, strDefaultSort);
	CString strDefaultCategory;
	mCb3.GetLBText(0, strDefaultCategory);
	LoadBooksFromServer(_T("title"), _T(""), strDefaultSort, _T(""));
}

HBITMAP LoadPngToHBITMAP(CString path)
{
	Bitmap bmp(path);
	HBITMAP hBmp = NULL;
	bmp.GetHBITMAP(Color(255, 255, 255), &hBmp);
	return hBmp;
}
HBITMAP ResizeHBITMAP(HBITMAP hSrcBmp, int nNewWidth, int nNewHeight)
{
	Bitmap* pSrcBitmap = Bitmap::FromHBITMAP(hSrcBmp, NULL);
	if (!pSrcBitmap) return NULL;

	Bitmap destBitmap(nNewWidth, nNewHeight);

	Graphics graphics(&destBitmap);
	graphics.SetInterpolationMode(InterpolationModeHighQualityBicubic); 

	graphics.DrawImage(pSrcBitmap, 0, 0, nNewWidth, nNewHeight);

	HBITMAP hDestBmp = NULL;
	destBitmap.GetHBITMAP(Color(255, 255, 255), &hDestBmp);

	delete pSrcBitmap;
	return hDestBmp;
}


BOOL C객체지향언어기말프로젝트View::OnPreparePrinting(CPrintInfo* pInfo)
{
	return DoPreparePrinting(pInfo);
}

void C객체지향언어기말프로젝트View::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void C객체지향언어기말프로젝트View::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
}

void C객체지향언어기말프로젝트View::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
}


// C객체지향언어기말프로젝트View 진단

#ifdef _DEBUG
void C객체지향언어기말프로젝트View::AssertValid() const
{
	CFormView::AssertValid();
}

void C객체지향언어기말프로젝트View::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

C객체지향언어기말프로젝트Doc* C객체지향언어기말프로젝트View::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(C객체지향언어기말프로젝트Doc)));
	return (C객체지향언어기말프로젝트Doc*)m_pDocument;
}
#endif //_DEBUG


// C객체지향언어기말프로젝트View 메시지 처리기

void C객체지향언어기말프로젝트View::OnBnClickedUserform()
{
	if (ud == NULL) {
		ud = new UserDlg(this);
		ud->Create(IDD_User);
		ud->ShowWindow(SW_SHOW);
	}
	else {
		ud->SetFocus();
	}
}

void C객체지향언어기말프로젝트View::OnBnClickedBookform()
{
	if (bd == NULL) {
		bd = new bookDIg(this);
		bd->Create(IDD_Book_reg);
		bd->ShowWindow(SW_SHOW);
	}
	else {
		bd->SetFocus();
	}
}

void C객체지향언어기말프로젝트View::OnBnClickedLoanform()
{
}

void C객체지향언어기말프로젝트View::OnBnClickedMainsearch()
{
	CString strKeyword;
	MainEc.GetWindowText(strKeyword); 

	int nSel = mCbs.GetCurSel(); 
	CString strType;
	if (nSel != LB_ERR) {
		mCbs.GetLBText(nSel, strType);
	}
	else {
		strType = _T("제목");
	}
	int nSelSort = mCbc.GetCurSel();
	CString strSortOrder;
	if (nSelSort != LB_ERR) {
		mCbc.GetLBText(nSelSort, strSortOrder);
	}
	else {
		strSortOrder = _T("최신순"); 
	}

	int nSelCategory = mCb3.GetCurSel();
	CString strCategory;
	if (nSelCategory != LB_ERR) {
		mCb3.GetLBText(nSelCategory, strCategory);
	}
	else {
		strCategory = _T("");
	}

	
	LoadBooksFromServer(strType, strKeyword, strSortOrder, strCategory);
}

CString EncodeStringToUrlUtf8(const CString& str)
{
	if (str.IsEmpty()) {
		return _T("");
	}

	
	int nUtf8Len = WideCharToMultiByte(CP_UTF8, 0, str, -1, NULL, 0, NULL, NULL);
	if (nUtf8Len == 0) return _T("");

	std::vector<char> utf8Buffer(nUtf8Len);
	WideCharToMultiByte(CP_UTF8, 0, str, -1, utf8Buffer.data(), nUtf8Len, NULL, NULL);

	
	CString strEncoded;
	for (int i = 0; i < nUtf8Len - 1; ++i) 
	{
		unsigned char byte = (unsigned char)utf8Buffer[i];
		if (isalnum(byte) || byte == '-' || byte == '_' || byte == '.' || byte == '~')
		{
			strEncoded += (TCHAR)byte;
		}
		else
		{
			strEncoded.AppendFormat(_T("%%%02X"), byte);
		}
	}

	return strEncoded;
}
void C객체지향언어기말프로젝트View::LoadBooksFromServer(CString type, CString keyword, CString sortOrder, CString category)
{
	CInternetSession session(_T("MyLibrarySession"), 1, INTERNET_OPEN_TYPE_DIRECT);

	session.SetOption(INTERNET_OPTION_CONNECT_TIMEOUT, 60000);
	session.SetOption(INTERNET_OPTION_SEND_TIMEOUT, 60000);
	session.SetOption(INTERNET_OPTION_RECEIVE_TIMEOUT, 60000);
	CHttpConnection* pConnection = NULL;
	CHttpFile* pFile = NULL;

	
	TCHAR szExePath[MAX_PATH];
	GetModuleFileName(NULL, szExePath, MAX_PATH); 

	CString strIniPath = szExePath;
	int nPos = strIniPath.ReverseFind('\\'); 
	if (nPos != -1)
	{
		strIniPath = strIniPath.Left(nPos); 
	}
	strIniPath += _T("\\config.ini"); 


	TCHAR szHost[256];

	
	::GetPrivateProfileString(_T("Server"), _T("Host"), _T("localhost"), szHost, 256, strIniPath);
	CString strServer = szHost;

	TCHAR szPort[64];
	
	::GetPrivateProfileString(_T("Server"), _T("Port"), _T("8080"), szPort, 64, strIniPath);

	INTERNET_PORT nPort;

	if (CString(szPort).CompareNoCase(_T("INTERNET_DEFAULT_HTTPS_PORT")) == 0) {
		nPort = INTERNET_DEFAULT_HTTPS_PORT;
	}
	else {
		nPort = (INTERNET_PORT)_ttoi(szPort);
	}

	
	DWORD dwSecure = ::GetPrivateProfileInt(_T("Server"), _T("Secure"), 0, strIniPath);
	DWORD dwSecureFlag = (dwSecure == 1) ? INTERNET_FLAG_SECURE : 0;
	

	try {
		
		CString strTypeServer = (type == _T("제목")) ? _T("title") : (type == _T("저자") ? _T("author") : _T("title"));

		
		CString strKeywordEncoded = EncodeStringToUrlUtf8(keyword);
		CString strSortServer;
		if (sortOrder == _T("최신순")) {
			
			strSortServer = _T("regDateDesc");
		}
		else if (sortOrder == _T("제목순")) {
			
			strSortServer = _T("titleAsc");
		}
		else {
			strSortServer = _T("regDateDesc");
		}
		CString strCategoryEncoded = (category.IsEmpty() || category == _T("전체"))
			? _T("")
			: EncodeStringToUrlUtf8(category);
		
		CString strObject;
		strObject.Format(_T("/book/search?type=%s&keyword=%s&sort=%s&category=%s"),
			strTypeServer,
			strKeywordEncoded,
			strSortServer,
			strCategoryEncoded);

		ATLTRACE(_T("서버 요청 URL: %s\n"), strObject);

		pConnection = session.GetHttpConnection(strServer, nPort);

	
		DWORD dwFlags = dwSecureFlag | INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE;

		dwFlags |= INTERNET_FLAG_IGNORE_CERT_CN_INVALID | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID;
		
		pFile = pConnection->OpenRequest(_T("GET"), strObject, NULL, 1, NULL, NULL, dwFlags);
		CString strHeaders = _T("ngrok-skip-browser-warning: 69420\r\nUser-Agent: MyMFCClient/1.0\r\n");
		pFile->AddRequestHeaders(strHeaders);
		
		pFile->SendRequest();

		DWORD dwRet;
		pFile->QueryInfoStatusCode(dwRet);

		if (dwRet == HTTP_STATUS_OK) {
			CString strResponse;

			
			DWORD dwTotalLength = 0;
			DWORD dwRead;

			
			CByteArray buffer;
			buffer.SetSize(4096, 4096);

			while (pFile != NULL && (dwRead = pFile->Read(buffer.GetData() + dwTotalLength, buffer.GetSize() - dwTotalLength)) > 0) {
				dwTotalLength += dwRead;

				
				if (dwTotalLength >= buffer.GetSize()) {
					buffer.SetSize(buffer.GetSize() + 4096, 4096);
				}
			}
			buffer.SetSize(dwTotalLength); 

			
			if (dwTotalLength > 0) {
				int nRequiredLen = MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)buffer.GetData(), dwTotalLength, NULL, 0);

				if (nRequiredLen > 0) {
					LPTSTR pszWideChar = strResponse.GetBuffer(nRequiredLen);
					MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)buffer.GetData(), dwTotalLength, pszWideChar, nRequiredLen);
					strResponse.ReleaseBuffer(nRequiredLen);
				}
			}
			

			ATLTRACE(_T("서버 응답 데이터: %s\n"), strResponse);

			
			mLc.SetRedraw(FALSE);
			mLc.DeleteAllItems();

			int nIndex = 0;


			CString jsonArrayContent = strResponse.Trim();
			auto GetField = [&](CString src, CString key) -> CString {
				CString token = key + _T("\":\"");
				int start = src.Find(token);
				if (start == -1) return _T("");
				start += token.GetLength();
				int end = src.Find(_T("\""), start);
				return src.Mid(start, end - start);
				};
			
			auto GetNumberField = [&](CString src, CString key) -> CString {
				CString token_num = key + _T("\":"); 
				CString token_str = key + _T("\":\""); 
				int start = -1;
				int end = -1;
				bool isStringFormat = false; 

				
				start = src.Find(token_num);
				if (start != -1) {
					start += token_num.GetLength();
				}
				else {
					
					start = src.Find(token_str);
					if (start != -1) {
						start += token_str.GetLength();
						isStringFormat = true; 
						end = src.Find(_T("\""), start); 
					}
				}

				if (start == -1) return _T("0"); 

				if (end == -1) {
					
					int end1 = src.Find(_T(','), start);
					int end2 = src.Find(_T('}'), start);

					
					if (end1 != -1 && end2 != -1) {
						end = min(end1, end2);
					}
					else if (end1 != -1) {
						end = end1;
					}
					else if (end2 != -1) {
						end = end2;
					}
					else {
						end = src.GetLength();
					}
				}

				if (end != -1) {
					CString result = src.Mid(start, end - start).Trim();

					result.TrimLeft(_T('\"'));
					result.TrimRight(_T('\"'));

					
					if (result.CompareNoCase(_T("null")) == 0 || result.IsEmpty()) {
						return _T("0");
					}
					return result;
				}
				return _T("0");
				};

			if (jsonArrayContent.GetLength() > 1 && jsonArrayContent[0] == _T('[') && jsonArrayContent[jsonArrayContent.GetLength() - 1] == _T(']')) {
				jsonArrayContent = jsonArrayContent.Mid(1, jsonArrayContent.GetLength() - 2);
			}
			else {
				if (jsonArrayContent.IsEmpty()) {
					ATLTRACE(_T("응답 데이터가 비어있습니다 (DB에 책 없음).\n"));
					goto cleanup;
				}
			}

			
			

			int nStart = 0;
			
			while (TRUE) {
				int nEnd = jsonArrayContent.Find(_T('}'), nStart);
				if (nEnd == -1 || nEnd <= nStart) break;

				CString jsonObj = jsonArrayContent.Mid(nStart, nEnd - nStart + 1);
				jsonObj.TrimLeft(_T(" \t,"));

				
				CString bookIdStr;
				CString token = _T("\"bookID\":"); 
				int start = jsonObj.Find(token);

				if (start != -1) {
					start += token.GetLength();
					int end1 = jsonObj.Find(_T(','), start); 
					int end2 = jsonObj.Find(_T('}'), start); 

					int end = -1;
					if (end1 != -1 && end2 != -1) {
						end = min(end1, end2);
					}
					else if (end1 != -1) {
						end = end1;
					}
					else {
						end = end2;
					}

					if (end != -1) {
						bookIdStr = jsonObj.Mid(start, end - start).Trim();
					}
				}
				DWORD bookId = _ttoi(bookIdStr);
			

				CString title = GetField(jsonObj, _T("title"));
				CString author = GetField(jsonObj, _T("author")); 
				CString publisher = GetField(jsonObj, _T("publisher")); 
				CString status = GetField(jsonObj, _T("status")); 
				CString imgPath = GetField(jsonObj, _T("imagePath"));
				int imgIdx = -1;

				
				if (!imgPath.IsEmpty())
				{
					
					
					CString strBaseUrl;
					if ((dwSecureFlag & INTERNET_FLAG_SECURE) && nPort == INTERNET_DEFAULT_HTTPS_PORT)
					{
						strBaseUrl.Format(_T("https://%s"), strServer);
					}
					else
					{
						strBaseUrl.Format(_T("http%s://%s:%u"),
							(dwSecureFlag & INTERNET_FLAG_SECURE) ? _T("s") : _T(""),
							strServer,
							nPort);
					}

					CString strImageUrl = strBaseUrl + imgPath;
					ATLTRACE(_T("이미지 URL: %s\n"), strImageUrl);
					auto it = m_imageCache.find(strImageUrl);
					if (it != m_imageCache.end())
					{
						
						imgIdx = it->second;
					}
					else
					{
						
						HBITMAP hBmpOriginal = LoadImageFromURL(strImageUrl);

						if (hBmpOriginal)
						{
							const int FINAL_SIZE = 150;
							HBITMAP hBmpResized = ResizeHBITMAP(hBmpOriginal, FINAL_SIZE, FINAL_SIZE);

							CBitmap bmp;
							bmp.Attach(hBmpResized);

							imgIdx = mImageList.Add(&bmp, RGB(255, 255, 255));

							bmp.Detach();
							DeleteObject(hBmpOriginal);

							
							m_imageCache[strImageUrl] = imgIdx;
						}
					}
				}
			
				CString info;
				if (status.IsEmpty()) status = _T("대출 가능");
				CString totalCountStr = GetNumberField(jsonObj, _T("totalCount")); 
				CString availableCountStr = GetNumberField(jsonObj, _T("availableCount")); 

				info.Format(_T("제목: %s\n저자: %s\n출판사: %s\n%s\n대출 가능 권수: %s/%s"),
					title,
					author,
					publisher,
					status,
					availableCountStr,
					totalCountStr);

				int itemIndex = mLc.InsertItem(nIndex++, info, imgIdx);

				
				if (bookId > 0)
				{
					mLc.SetItemData(itemIndex, (DWORD_PTR)bookId);
				}

				
				nStart = nEnd + 1;
			}
			

		cleanup:
			mLc.SetRedraw(TRUE);
		}
	}
	catch (CInternetException* pEx) {
		
		pEx->ReportError();
		pEx->Delete();
	}

	
	if (pFile) { pFile->Close(); delete pFile; }
	if (pConnection) { pConnection->Close(); delete pConnection; }
	

	mLc.Invalidate();
}

HBITMAP C객체지향언어기말프로젝트View::LoadImageFromURL(CString url)
{
	
	DWORD dwImageFlags = INTERNET_FLAG_IGNORE_CERT_CN_INVALID | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID;

	
	static CInternetSession session(
		_T("MyImageSession"),
		1,
		INTERNET_OPEN_TYPE_PRECONFIG,
		NULL,
		NULL,
		INTERNET_FLAG_IGNORE_CERT_CN_INVALID | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID
	);
	
	CHttpFile* pFile = NULL;
	HBITMAP hResult = NULL;

	try {
		CString strHeaders = _T("ngrok-skip-browser-warning: 69420");
		pFile = (CHttpFile*)session.OpenURL(url, 1, INTERNET_FLAG_TRANSFER_BINARY | INTERNET_FLAG_RELOAD, strHeaders, -1);
		if (pFile) {
			
			DWORD dwFileSize = (DWORD)pFile->GetLength(); 

			CFile tempFile;

			TCHAR szPath[MAX_PATH];
			GetTempPath(MAX_PATH, szPath);
			CString tempPath;
			tempPath.Format(_T("%stemp_img_%u.png"), szPath, GetTickCount());

			if (tempFile.Open(tempPath, CFile::modeCreate | CFile::modeWrite)) {
				const int BUF_SIZE = 4096;
				BYTE buffer[BUF_SIZE];
				UINT nRead;
				while ((nRead = pFile->Read(buffer, BUF_SIZE)) > 0) {
					tempFile.Write(buffer, nRead);
				}
				tempFile.Close();


				hResult = LoadPngToHBITMAP(tempPath);


				DeleteFile(tempPath);
			}
		}
	}
	catch (...) {

	}

	if (pFile) { pFile->Close(); delete pFile; }
	

	return hResult;
}
void C객체지향언어기말프로젝트View::OnNMCustomdrawList1(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMLVCUSTOMDRAW pLVCD = reinterpret_cast<LPNMLVCUSTOMDRAW>(pNMHDR);
	*pResult = CDRF_DODEFAULT;

	switch (pLVCD->nmcd.dwDrawStage)
	{
	case CDDS_PREPAINT:
		*pResult = CDRF_NOTIFYITEMDRAW;
		return;

	case CDDS_ITEMPREPAINT:
	{
		CDC* pDC = CDC::FromHandle(pLVCD->nmcd.hdc);
		int index = static_cast<int>(pLVCD->nmcd.dwItemSpec);

		CRect rc = pLVCD->nmcd.rc;
		BOOL bSelected = (pLVCD->nmcd.uItemState & CDIS_SELECTED);
		BOOL bFocused = (pLVCD->nmcd.uItemState & CDIS_FOCUS);

		
		COLORREF bgColor = bSelected
			? RGB(220, 235, 255)
			: RGB(255, 255, 255);

		pDC->FillSolidRect(rc, bgColor);

		if (bFocused)
		{
			pDC->DrawFocusRect(rc);
		}
		LVITEM lvi = { 0 };
		lvi.iItem = index;
		lvi.iSubItem = 0;
		lvi.mask = LVIF_IMAGE;
		mLc.GetItem(&lvi);
		int imgIndex = lvi.iImage;

		const int TARGET_IMG_SIZE = 120;
		const int PADDING = 40;

		int itemHeight = rc.Height();
		int imageTop = rc.top + (itemHeight - TARGET_IMG_SIZE) / 2;

		CRect imageRc(
			rc.left + PADDING,
			imageTop,
			rc.left + PADDING + TARGET_IMG_SIZE,
			imageTop + TARGET_IMG_SIZE
		);


		if (imgIndex >= 0)
		{
			mImageList.Draw(
				pDC,
				imgIndex,
				CPoint(imageRc.left, imageRc.top),
				ILD_NORMAL
			);
		}

		CString text = mLc.GetItemText(index, 0);

		CRect textRc = rc;
		textRc.left = imageRc.right + PADDING;
		textRc.right = rc.right;
		textRc.top = rc.top; // 항목 상단에서 시작
		textRc.bottom = rc.bottom;


		pDC->DrawText(text, textRc, DT_LEFT | DT_WORDBREAK | DT_NOPREFIX | DT_TOP | DT_EDITCONTROL);

		

		*pResult = CDRF_SKIPDEFAULT;
		return;
	}
	}

	*pResult = CDRF_DODEFAULT;
}

void C객체지향언어기말프로젝트View::OnMeasureItem(int nIDCtl, LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
	if (nIDCtl == IDC_LIST1)
	{
		lpMeasureItemStruct->itemHeight = 240;
		return;
	}
	CFormView::OnMeasureItem(nIDCtl, lpMeasureItemStruct);
}
void C객체지향언어기말프로젝트View::OnCbnSelchangeCombo3()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	OnBnClickedMainsearch();
}

void C객체지향언어기말프로젝트View::OnCbnSelchangeCombo2()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	OnBnClickedMainsearch();
}

void C객체지향언어기말프로젝트View::OnNMClickList1(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	int nIndex = pNMItemActivate->iItem;

	*pResult = 0;

	
	
	if (nIndex < 0) return;

	DWORD bookId = mLc.GetItemData(nIndex);

	if (bd != NULL && bd->GetSafeHwnd() != NULL)
	{
		
		bd->m_bookId = bookId;

		bd->LoadBookDetail(bookId);
		bd->ShowWindow(SW_SHOW);
		bd->SetFocus();
	}
	*pResult = 0;
}
