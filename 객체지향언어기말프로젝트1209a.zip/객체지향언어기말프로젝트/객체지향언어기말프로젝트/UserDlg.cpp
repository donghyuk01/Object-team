﻿// UserDlg.cpp: 구현 파일
//

#include "pch.h"
#include "객체지향언어기말프로젝트.h"
#include "afxdialogex.h"
#include "UserDlg.h"

#include"객체지향언어기말프로젝트Doc.h"
#include"객체지향언어기말프로젝트View.h"
#include"LoanDlg.h"
#include <sqltypes.h>
// UserDlg 대화 상자

IMPLEMENT_DYNAMIC(UserDlg, CDialogEx)

UserDlg::UserDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_User, pParent)
{
	userView = (C객체지향언어기말프로젝트View*)pParent;
    ld = NULL;
}

UserDlg::~UserDlg()
{
}

void UserDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT5, userName);
	DDX_Control(pDX, IDC_EDIT8, birth);
	DDX_Control(pDX, IDC_EDIT9, maxLoan);
	DDX_Control(pDX, IDC_EDIT10, solveDate);
	DDX_Control(pDX, IDC_COMBO1, statusBox);
	DDX_Control(pDX, IDC_LIST1, user_lc);
}


BEGIN_MESSAGE_MAP(UserDlg, CDialogEx)
	/*ON_BN_CLICKED(ID_UserCancel, &UserDlg::OnBnClickedUsercancel)*/
	ON_BN_CLICKED(IDC_BUTTON5, &UserDlg::OnBnClickedButton5)
    ON_BN_CLICKED(IDC_LoanButton, &UserDlg::OnBnClickedLoanbutton)
    ON_BN_CLICKED(IDC_BUTTON1, &UserDlg::OnBnClickedButton1)
END_MESSAGE_MAP()


// UserDlg 메시지 처리기
BOOL UserDlg::OnInitDialog()
{
    CDialogEx::OnInitDialog();

    // TODO:  여기에 추가 초기화 작업을 추가합니다.
    statusBox.ResetContent();
    statusBox.AddString(_T("정상"));
    statusBox.AddString(_T("연체 정지"));
    statusBox.AddString(_T("자격 정지"));
    statusBox.AddString(_T("탈퇴"));
    statusBox.SetCurSel(0);

    user_lc.SetExtendedStyle(LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);

    
    user_lc.InsertColumn(0, _T("도서 ID"), LVCFMT_LEFT, 120); 
    user_lc.InsertColumn(1, _T("대출일"), LVCFMT_LEFT, 200);
    user_lc.InsertColumn(2, _T("반납 예정일"), LVCFMT_LEFT, 200);
    user_lc.InsertColumn(3, _T("상태"), LVCFMT_LEFT, 80);
    user_lc.InsertColumn(4, _T("연체일수"), LVCFMT_RIGHT, 80);

    statusBox.SetCurSel(0);
    return TRUE;  // return TRUE unless you set the focus to a control
    // 예외: OCX 속성 페이지는 FALSE를 반환해야 합니다.
}
void UserDlg::OnCancel()
{
    
    userView->ud = NULL;
    
    CDialogEx::OnCancel();
}

void UserDlg::LoadUserLoanList(const CString& strUserID)
{
    // 리스트 컨트롤 초기화
    user_lc.DeleteAllItems();

    CDatabase* pDB = &userView->db;

    if (pDB == NULL || !pDB->IsOpen())
    {
        AfxMessageBox(_T("데이터베이스 연결 상태를 확인해주세요."));
        return;
    }

    
    CString strSQL;
    strSQL.Format(_T("SELECT ")
        _T("BI.itemID, L.LoanDate, L.DueDate, L.LoanStatus, L.OverdueDays ")
        _T("FROM mir9876.Loan L ")
        _T("JOIN mir9876.Book_item BI ON L.ItemID = BI.itemID ")
        _T("WHERE L.UserID = %s AND L.LoanStatus IN ('대출 중', '연체') ") 
        _T("ORDER BY L.LoanDate DESC"),
        strUserID);

    CRecordset rs(pDB);
    TRY
    {
        if (!rs.Open(CRecordset::forwardOnly, strSQL))
        {
            AfxMessageBox(_T("대출 목록 조회 쿼리 실행에 실패했습니다."));
            return;
        }

        int nRow = 0;
        while (!rs.IsEOF())
        {
            
            CString strItemID, strLoanDate, strDueDate, strLoanStatus, strOverdueDays;

            rs.GetFieldValue(_T("itemID"), strItemID);
            rs.GetFieldValue(_T("LoanDate"), strLoanDate);
            rs.GetFieldValue(_T("DueDate"), strDueDate);
            rs.GetFieldValue(_T("LoanStatus"), strLoanStatus);
            rs.GetFieldValue(_T("OverdueDays"), strOverdueDays);

            
            int nSpacePos = strLoanDate.Find(' ');
            if (nSpacePos != -1)
            {
                strLoanDate = strLoanDate.Left(nSpacePos);
            }

            
            user_lc.InsertItem(nRow, strItemID);          
            user_lc.SetItemText(nRow, 1, strLoanDate);   
            user_lc.SetItemText(nRow, 2, strDueDate);     
            user_lc.SetItemText(nRow, 3, strLoanStatus);  
            user_lc.SetItemText(nRow, 4, strOverdueDays); 


            rs.MoveNext();
            nRow++;
        }
    }
        CATCH(CDBException, e)
    {
        AfxMessageBox(_T("대출 목록 조회 중 데이터베이스 오류 발생: ") + e->m_strError);
    }
    END_CATCH

        rs.Close();
}

void UserDlg::OnBnClickedButton5()
{
    
    CString strName, strBirth;
    userName.GetWindowText(strName);
    birth.GetWindowText(strBirth);

   
    if (strName.IsEmpty() || strBirth.IsEmpty())
    {
        AfxMessageBox(_T("이름과 생년월일을 모두 입력해주세요."));
        return;
    }

    
    CDatabase* pDB = &userView->db;

    
    if (pDB == NULL || !pDB->IsOpen())
    {
        AfxMessageBox(_T("데이터베이스 연결 상태를 확인해주세요."));
        return;
    }

    
    CString strSQL;
    strSQL.Format(_T("SELECT userID, maxLoan, solveDate, status FROM mir9876.User WHERE name='%s' AND birth='%s'"),
        strName, strBirth);

    CRecordset rs(pDB);
    TRY
    {

        if (!rs.Open(CRecordset::forwardOnly, strSQL))
        {
            AfxMessageBox(_T("회원 조회 쿼리 실행에 실패했습니다."));
            return;
        }

    
    if (rs.IsEOF())
    {
        
        AfxMessageBox(_T("입력하신 이름과 생년월일로 등록된 회원이 없습니다."));

        
        maxLoan.SetWindowText(_T(""));
        solveDate.SetWindowText(_T(""));
        statusBox.SetCurSel(-1); 
    }
    else
    {
        
        CString strUserID, strMaxLoan, strSolveDate, strStatus;

        
        rs.GetFieldValue(_T("userID"), strUserID);
        rs.GetFieldValue(_T("maxLoan"), strMaxLoan);
        rs.GetFieldValue(_T("solveDate"), strSolveDate);
        rs.GetFieldValue(_T("status"), strStatus);

        m_strUserID = strUserID;
        LoadUserLoanList(strUserID);
        

        int nMaxLoanLimit = _ttoi(strMaxLoan);         // 최대 한도를 숫자로 변환
        int nCurrentLoanCount = user_lc.GetItemCount(); // 현재 대출 중인 권수 획득
        int nRemainingLoanCount = nMaxLoanLimit - nCurrentLoanCount; // 남은 권수 계산

        CString strRemainingCount;
        strRemainingCount.Format(_T("%d"), nRemainingLoanCount);

        // 3. 계산된 남은 권수를 UI에 표시
        maxLoan.SetWindowText(strRemainingCount);

        if (strSolveDate.IsEmpty() || strSolveDate == _T("0000-00-00"))
        {
            solveDate.SetWindowText(_T("없음"));
        }
        else
        {
            solveDate.SetWindowText(strSolveDate);
        }

        
        int index = statusBox.FindStringExact(-1, strStatus);
        if (index != CB_ERR)
        {
            statusBox.SetCurSel(index);
        }
        else
        {
            statusBox.SetCurSel(-1);
        }

  
        /*LoadUserLoanList(strUserID);*/ 
    }
    }
        CATCH(CDBException, e)
    {
        
        AfxMessageBox(e->m_strError);
        
        maxLoan.SetWindowText(_T(""));
        solveDate.SetWindowText(_T(""));
        statusBox.SetCurSel(-1);
    }
    END_CATCH

        rs.Close(); 


}



void UserDlg::OnBnClickedLoanbutton()
{
    // TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
    if (ld == NULL) {
        ld = new LoanDlg(&userView->db, this);
        CString strUserName;
        userName.GetWindowText(strUserName);
        ld->m_strUserID = m_strUserID;
        ld->m_strUserName = strUserName;
        ld->Create(IDD_Loan);
        ld->ShowWindow(SW_SHOW);
    }
    else {
        ld->SetFocus();
    }
    
}
void UserDlg::RefreshUserInfo()
{
    if (m_strUserID.IsEmpty())
        return;

    CDatabase* pDB = &userView->db;
    if (!pDB || !pDB->IsOpen())
        return;

    CString strSQL;
    strSQL.Format(
        _T("SELECT userID, maxLoan, solveDate, status ")
        _T("FROM mir9876.User WHERE userID = %s"),
        m_strUserID
    );

    CRecordset rs(pDB);

    TRY
    {
        rs.Open(CRecordset::forwardOnly, strSQL);

        if (!rs.IsEOF())
        {
            CString strMaxLoan, strSolveDate, strStatus;

            rs.GetFieldValue(_T("maxLoan"), strMaxLoan);
            rs.GetFieldValue(_T("solveDate"), strSolveDate);
            rs.GetFieldValue(_T("status"), strStatus);

            
            LoadUserLoanList(m_strUserID);
            int nMaxLoanLimit = _ttoi(strMaxLoan);
            int nCurrentLoanCount = user_lc.GetItemCount();
            int nRemain = nMaxLoanLimit - nCurrentLoanCount;

            CString strRemain;
            strRemain.Format(_T("%d"), nRemain);
            maxLoan.SetWindowText(strRemain);

            if (strSolveDate.IsEmpty() || strSolveDate == _T("0000-00-00"))
                solveDate.SetWindowText(_T("없음"));
            else
                solveDate.SetWindowText(strSolveDate);

            int idx = statusBox.FindStringExact(-1, strStatus);
            statusBox.SetCurSel(idx != CB_ERR ? idx : -1);
        }
    }
        CATCH(CDBException, e)
    {
        e->Delete();
    }
    END_CATCH

        rs.Close();
}


void UserDlg::OnBnClickedButton1()
{
    // TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
    CDatabase* pDB = &userView->db;

    if (pDB == NULL || !pDB->IsOpen()) {
        AfxMessageBox(_T("데이터베이스 연결 상태를 확인해주세요."));
        return;
    }

    CString strSQL = _T("SELECT phone, solveDate FROM mir9876.User");

    CRecordset rs(pDB);

    // [SendSMS 로직 통합 시작]
    TCHAR exePath[MAX_PATH];
    GetModuleFileName(NULL, exePath, MAX_PATH);
    PathRemoveFileSpec(exePath);
    _tcscat_s(exePath, _T("\\send_sms.exe"));

    if (GetFileAttributes(exePath) == INVALID_FILE_ATTRIBUTES)
    {
        AfxMessageBox(_T("오류: send_sms.exe 파일을 찾을 수 없습니다. 프로그램 폴더에 넣어주세요."));
        return;
    }
    // [SendSMS 로직 통합 끝]

    TRY
    {
        rs.Open(CRecordset::forwardOnly, strSQL, CRecordset::readOnly);

        if (rs.IsEOF()) {
            AfxMessageBox(_T("연체 회원이 없습니다."));
            rs.Close();
            return;
        }

        // 현재 날짜를 가져와서 시간을 00:00:00으로 설정 (날짜 비교 기준)
        COleDateTime dtCurrent = COleDateTime::GetCurrentTime();
        // **수정 1: 현재 날짜의 시간을 자정으로 초기화**
        COleDateTime dtToday(dtCurrent.GetYear(), dtCurrent.GetMonth(), dtCurrent.GetDay(), 0, 0, 0);

        CString strPhone;
        CString strSolveDate;
        COleDateTime solveDate;
        COleDateTime dtSolveDay; // solveDate의 날짜만 저장할 변수
        CString strMessage;
        long lDaysRemaining;

        while (!rs.IsEOF())
        {
            rs.GetFieldValue((short)0, strPhone);
            rs.GetFieldValue((short)1, strSolveDate);

            strPhone.Trim();
            strSolveDate.Trim();

            if (solveDate.ParseDateTime(strSolveDate))
            {
                // **수정 2: solveDate의 시간을 자정으로 초기화하여 순수 날짜만 비교**
                dtSolveDay.SetDate(solveDate.GetYear(), solveDate.GetMonth(), solveDate.GetDay());

                COleDateTimeSpan span = dtSolveDay - dtToday;
                lDaysRemaining = span.GetDays();

                // 연체 (< 0) 또는 기한 임박 (<= 2일 남음) 확인
                // lDaysRemaining이 0이면 오늘이 기한, 1이면 내일이 기한
                if (lDaysRemaining < 0 || lDaysRemaining <= 2)
                {
                    if (lDaysRemaining < 0)
                    {
                        // 연체 메시지 생성
                        // (solveDate의 시간 포맷은 그대로 유지해도 되지만, 깔끔하게 날짜만 포맷함)
                        strMessage.Format(_T("알림: 연체 해결 기한인 %s이(가) %ld일 지났습니다. 즉시 처리해 주세요."),
                                          dtSolveDay.Format(_T("%Y-%m-%d")), -lDaysRemaining);
                    }
                    else
                    {
                        // 기한 임박 메시지 생성
                        strMessage.Format(_T("연체 해결 기한(%s)이 %ld일 남았습니다. 신속히 처리 바랍니다."),
                                          dtSolveDay.Format(_T("%Y-%m-%d")), lDaysRemaining);
                    }

                    // [SMS 전송 실행 로직] (이하 동일)
                    CString cmdLine;
                    cmdLine.Format(_T("\"%s\" \"%s\" \"%s\""), exePath, strPhone, strMessage);

                    STARTUPINFO si = { sizeof(si) };
                    PROCESS_INFORMATION pi;
                    si.dwFlags = STARTF_USESHOWWINDOW;
                    si.wShowWindow = SW_HIDE;

                    if (CreateProcess(NULL, cmdLine.GetBuffer(), NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi))
                    {
                        WaitForSingleObject(pi.hProcess, 15000);
                        CloseHandle(pi.hProcess);
                        CloseHandle(pi.hThread);
                        TRACE(_T("SMS 전송 명령 실행됨 => %s : %s\n"), strPhone, strMessage);
                    }
                    else
                    {
                        TRACE(_T("경고: send_sms.exe 실행 실패! (대상: %s)\n"), strPhone);
                    }
                    // [SMS 전송 실행 로직 끝]
                }
            }
            else
            {
                TRACE(_T("경고: 전화번호 %s의 solveDate 값 (%s)이 유효하지 않은 형식입니다.\n"), strPhone, strSolveDate);
            }

            rs.MoveNext();
        }
    }
        CATCH(CDBException, e)
    {
        AfxMessageBox(e->m_strError);
    }
    END_CATCH

        if (rs.IsOpen()) rs.Close();
}
