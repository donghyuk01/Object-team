const express = require('express');
const router = express.Router();
const db = require('../db/db'); // 필요 시 주석 해제


module.exports = router;