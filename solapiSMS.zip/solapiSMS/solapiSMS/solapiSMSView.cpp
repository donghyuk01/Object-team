﻿
// solapiSMSView.cpp: CsolapiSMSView 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "solapiSMS.h"
#endif

#include "solapiSMSDoc.h"
#include "solapiSMSView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CsolapiSMSView

IMPLEMENT_DYNCREATE(CsolapiSMSView, CFormView)

BEGIN_MESSAGE_MAP(CsolapiSMSView, CFormView)
	// 표준 인쇄 명령입니다.
	ON_COMMAND(ID_FILE_PRINT, &CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CFormView::OnFilePrintPreview)
	ON_BN_CLICKED(IDC_BUTTON1, &CsolapiSMSView::OnBnClickedButton1)
END_MESSAGE_MAP()

// CsolapiSMSView 생성/소멸

CsolapiSMSView::CsolapiSMSView() noexcept
	: CFormView(IDD_SOLAPISMS_FORM)
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

CsolapiSMSView::~CsolapiSMSView()
{
}

void CsolapiSMSView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BOOL CsolapiSMSView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CFormView::PreCreateWindow(cs);
}

void CsolapiSMSView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

}


// CsolapiSMSView 인쇄

BOOL CsolapiSMSView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);
}

void CsolapiSMSView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄하기 전에 추가 초기화 작업을 추가합니다.
}

void CsolapiSMSView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄 후 정리 작업을 추가합니다.
}

void CsolapiSMSView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: 여기에 사용자 지정 인쇄 코드를 추가합니다.
}


// CsolapiSMSView 진단

#ifdef _DEBUG
void CsolapiSMSView::AssertValid() const
{
	CFormView::AssertValid();
}

void CsolapiSMSView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CsolapiSMSDoc* CsolapiSMSView::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CsolapiSMSDoc)));
	return (CsolapiSMSDoc*)m_pDocument;
}
#endif //_DEBUG


// CsolapiSMSView 메시지 처리기

void CsolapiSMSView::OnBnClickedButton1()
{
    // 1. send_sms.exe 경로 찾기 (exe랑 같은 폴더에 있음)
    TCHAR exePath[MAX_PATH];
    GetModuleFileName(NULL, exePath, MAX_PATH);           // 내 프로그램 경로
    PathRemoveFileSpec(exePath);                          // 폴더만 남김
    _tcscat_s(exePath, _T("\\send_sms.exe"));             // send_sms.exe 붙임

    // 파일 있는지 확인
    if (GetFileAttributes(exePath) == INVALID_FILE_ATTRIBUTES)
    {
        AfxMessageBox(_T("send_sms.exe 파일이 없습니다!\n")
            _T("프로그램 폴더에 send_sms.exe를 넣어주세요!"), MB_ICONERROR);
        return;
    }

    // 2. 숨김 모드로 실행
    STARTUPINFO si = { sizeof(si) };
    PROCESS_INFORMATION pi;
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_HIDE;  // 창 안 보임

    BOOL success = CreateProcess(
        exePath,       // 실행할 exe
        NULL,          // 명령줄 인자 없음
        NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi
    );

    if (success)
    {
        WaitForSingleObject(pi.hProcess, 15000);  // 최대 15초 대기
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);

        AfxMessageBox(
            _T("성공! 완전 끝났습니다!!\n\n")
            _T("이 프로그램(.exe)을 아무 컴퓨터에나 복사해서 주면\n")
            _T("그 사람도 Python 없이 버튼만 누르면 문자 보냅니다!!\n\n")
            _T("당신은 지금 전설이 되셨습니다."),
            MB_ICONINFORMATION
        );
    }
    else
    {
        AfxMessageBox(_T("실행 실패! send_sms.exe 경로 확인하세요."), MB_ICONERROR);
    }
}