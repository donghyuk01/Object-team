﻿// LoanDlg.cpp: 구현 파일
//

#include "pch.h"
#include "객체지향언어기말프로젝트.h"
#include "afxdialogex.h"
#include "LoanDlg.h"

#include"UserDlg.h"
// LoanDlg 대화 상자

IMPLEMENT_DYNAMIC(LoanDlg, CDialogEx)

LoanDlg::LoanDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_Loan, pParent)
{
	loanView = (UserDlg*)pParent;
}

LoanDlg::~LoanDlg()
{
}

void LoanDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(LoanDlg, CDialogEx)
	/*ON_BN_CLICKED(ID_LoanClose, &LoanDlg::OnBnClickedLoanclose)*/
END_MESSAGE_MAP()


// LoanDlg 메시지 처리기
void LoanDlg::OnCancel()
{
	// 부모 다이얼로그(UserDlg)의 포인터(ld)를 NULL로 초기화
	if (loanView) {
		loanView->ld = NULL;
	}
	// MFC의 안전한 종료 프로세스(DestroyWindow, PostNcDestroy->delete this)를 따름
	CDialogEx::OnCancel();
}
//void LoanDlg::OnBnClickedLoanclose()
//{
//	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
//	/*loanView->ld = NULL;
//	DestroyWindow();
//	delete this;*/
//	OnCancel();
//}
