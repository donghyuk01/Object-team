﻿
// LoadBlobView.cpp: CLoadBlobView 클래스의 구현
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS는 미리 보기, 축소판 그림 및 검색 필터 처리기를 구현하는 ATL 프로젝트에서 정의할 수 있으며
// 해당 프로젝트와 문서 코드를 공유하도록 해 줍니다.
#ifndef SHARED_HANDLERS
#include "LoadBlob.h"
#endif

#include "LoadBlobDoc.h"
#include "LoadBlobView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CLoadBlobView

IMPLEMENT_DYNCREATE(CLoadBlobView, CFormView)

BEGIN_MESSAGE_MAP(CLoadBlobView, CFormView)
	// 표준 인쇄 명령입니다.
	ON_COMMAND(ID_FILE_PRINT, &CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CFormView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CFormView::OnFilePrintPreview)
	ON_BN_CLICKED(IDC_BUTTON1, &CLoadBlobView::OnBnClickedButton1)
    ON_BN_CLICKED(IDC_BUTTON2, &CLoadBlobView::OnBnClickedButton2)
END_MESSAGE_MAP()

// CLoadBlobView 생성/소멸

CLoadBlobView::CLoadBlobView() noexcept
	: CFormView(IDD_LOADBLOB_FORM)
{
	// TODO: 여기에 생성 코드를 추가합니다.

}

CLoadBlobView::~CLoadBlobView()
{
}

void CLoadBlobView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
}

BOOL CLoadBlobView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: CREATESTRUCT cs를 수정하여 여기에서
	//  Window 클래스 또는 스타일을 수정합니다.

	return CFormView::PreCreateWindow(cs);
}

void CLoadBlobView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();

	db.OpenEx(_T("DSN=blob;UID=mir9876;PWD=rlaehdgur;"), CDatabase::noOdbcDialog);
}


// CLoadBlobView 인쇄

BOOL CLoadBlobView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 기본적인 준비
	return DoPreparePrinting(pInfo);
}

void CLoadBlobView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄하기 전에 추가 초기화 작업을 추가합니다.
}

void CLoadBlobView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 인쇄 후 정리 작업을 추가합니다.
}

void CLoadBlobView::OnPrint(CDC* pDC, CPrintInfo* /*pInfo*/)
{
	// TODO: 여기에 사용자 지정 인쇄 코드를 추가합니다.
}


// CLoadBlobView 진단

#ifdef _DEBUG
void CLoadBlobView::AssertValid() const
{
	CFormView::AssertValid();
}

void CLoadBlobView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CLoadBlobDoc* CLoadBlobView::GetDocument() const // 디버그되지 않은 버전은 인라인으로 지정됩니다.
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLoadBlobDoc)));
	return (CLoadBlobDoc*)m_pDocument;
}
#endif //_DEBUG


// CLoadBlobView 메시지 처리기

void CLoadBlobView::OnBnClickedButton1()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
    try {
        // ODBC 연결 핸들 얻기
        HDBC hDbc = db.m_hdbc;
        SQLHSTMT hStmt;

        // Statement 핸들 할당
        SQLRETURN ret = SQLAllocHandle(SQL_HANDLE_STMT, hDbc, &hStmt);
        if (ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
            AfxMessageBox(_T("SQLAllocHandle 실패"));
            return;
        }

        // 유니코드 SQL 문
        SQLWCHAR sql[] = L"INSERT INTO mir9876.new_table (Img) VALUES (?)";

        // SQL 문 준비
        ret = SQLPrepareW(hStmt, sql, SQL_NTS);
        if (ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
            AfxMessageBox(_T("SQLPrepare 실패"));
            SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
            return;
        }

        // 이미지 파일 읽기
        std::ifstream file("C:\\Users\\cosmo\\source\\repos\\sqlblob\\x64\\Debug\\sample.png", std::ios::binary);
        if (!file.is_open()) {
            AfxMessageBox(_T("sample.png 파일을 열 수 없습니다"));
            SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
            return;
        }
        std::vector<char> buffer((std::istreambuf_iterator<char>(file)), {});

        // 길이 값 지정 (매우 중요)
        SQLLEN cbData = (SQLLEN)buffer.size();

        ret = SQLBindParameter(
            hStmt,
            1,
            SQL_PARAM_INPUT,
            SQL_C_BINARY,         // C 타입
            SQL_LONGVARBINARY,    // SQL 타입
            buffer.size(),
            0,
            (SQLPOINTER)buffer.data(),
            buffer.size(),
            &cbData               // ← 반드시 필요!
        );

        if (ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
            AfxMessageBox(_T("SQLBindParameter 실패"));
            SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
            return;
        }
        if (ret != SQL_SUCCESS && ret != SQL_SUCCESS_WITH_INFO) {
            AfxMessageBox(_T("SQLBindParameter 실패"));
            SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
            return;
        }

        // SQL 실행
        ret = SQLExecute(hStmt);
        if (ret == SQL_SUCCESS || ret == SQL_SUCCESS_WITH_INFO) {
            AfxMessageBox(_T("데이터 저장 완료"));
        }
        else {
            AfxMessageBox(_T("SQLExecute 실패"));
        }

        // 핸들 정리
        SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    }
    catch (...) {
        AfxMessageBox(_T("예외 발생"));
    }
}

void CLoadBlobView::ShowODBCError(SQLSMALLINT handleType, SQLHANDLE handle)
{
    SQLWCHAR szSqlState[6] = { 0 };
    SQLINTEGER nNativeError = 0;
    SQLWCHAR szMsg[SQL_MAX_MESSAGE_LENGTH] = { 0 };
    SQLSMALLINT nTextLength = 0;

    if (SQL_SUCCEEDED(SQLGetDiagRecW(handleType, handle, 1, szSqlState,
        &nNativeError, szMsg, _countof(szMsg), &nTextLength)))
    {
        CString str;
        str.Format(_T("ODBC 오류\n\n%s\n\nSQLSTATE: %s"), szMsg, szSqlState);
        AfxMessageBox(str, MB_ICONERROR);
    }
    else
    {
        AfxMessageBox(_T("ODBC 에러 정보를 가져오지 못했습니다."), MB_ICONERROR);
    }
}

void CLoadBlobView::OnBnClickedButton2()
{
    // TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
    try
    {
        HDBC hDbc = db.m_hdbc;
        SQLHSTMT hStmt = SQL_NULL_HSTMT;

        // 1. Statement 핸들 할당
        SQLRETURN ret = SQLAllocHandle(SQL_HANDLE_STMT, hDbc, &hStmt);
        if (!SQL_SUCCEEDED(ret)) {
            ShowODBCError(SQL_HANDLE_STMT, hStmt);
            return;
        }

        // 2. 쿼리 준비 및 실행 (Prepare + Execute 방식)
        SQLWCHAR sql[] = L"SELECT Img FROM mir9876.new_table WHERE i_id = 5";

        ret = SQLExecDirectW(hStmt, sql, SQL_NTS);   // Prepare + Execute를 한 번에
        if (!SQL_SUCCEEDED(ret)) {
            ShowODBCError(SQL_HANDLE_STMT, hStmt);
            SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
            return;
        }

        // 3. 한 행 가져오기
        ret = SQLFetch(hStmt);
        if (ret == SQL_NO_DATA) {
            AfxMessageBox(_T("i_id=5 인 데이터가 없습니다."));
            SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
            return;
        }
        if (!SQL_SUCCEEDED(ret)) {
            ShowODBCError(SQL_HANDLE_STMT, hStmt);
            SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
            return;
        }

        // 4. MEDIUMBLOB 데이터를 안전하게 chunk 단위로 읽기 (최대 16MB도 문제없음)
        const SQLLEN CHUNK_SIZE = 1024 * 1024;   // 1MB씩 읽기 (충분히 크게 잡아도 됨)
        std::vector<BYTE> buffer(CHUNK_SIZE);
        SQLLEN cbData = 0;

        // 저장할 파일 경로 (원하는 곳으로 바꾸세요)
        CString strFilePath = _T("C:\\Users\\cosmo\\Desktop\\new\\image_from_db.png");

        CFile file;
        if (!file.Open(strFilePath, CFile::modeCreate | CFile::modeWrite | CFile::typeBinary)) {
            AfxMessageBox(_T("파일 생성 실패:"+strFilePath));
            SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
            return;
        }

        bool bSuccess = true;
        while (true)
        {
            ret = SQLGetData(hStmt,               // hStmt
                1,                    // 컬럼 번호 (Img가 첫 번째 컬럼)
                SQL_C_BINARY,         // 바이너리로 받음
                buffer.data(),
                CHUNK_SIZE,
                &cbData);

            if (ret == SQL_NO_DATA) {            // 더 이상 데이터 없음 → 종료
                break;
            }

            if (!SQL_SUCCEEDED(ret)) {
                ShowODBCError(SQL_HANDLE_STMT, hStmt);
                bSuccess = false;
                break;
            }

            if (cbData == SQL_NULL_DATA) {
                AfxMessageBox(_T("Img 컬럼이 NULL입니다."));
                bSuccess = false;
                break;
            }
            else if (cbData > 0) {
                // 실제 읽은 크기만큼만 쓰기
                file.Write(buffer.data(), static_cast<UINT>(cbData));
            }
        }

        file.Close();

        if (bSuccess)
            AfxMessageBox(_T("MEDIUMBLOB → PNG 저장 성공!\n") + strFilePath);
        else
            ::DeleteFile(strFilePath);  // 실패했으면 파일 삭제

        // 5. 정리
        SQLCloseCursor(hStmt);
        SQLFreeHandle(SQL_HANDLE_STMT, hStmt);
    }
    catch (...) {
        AfxMessageBox(_T("예외 발생"));
    }
}
